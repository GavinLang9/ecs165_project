
PAGE_SIZE = 4096

class Page:
    def __init__(self, record_size=8):
        self.num_records = 0
        self.record_size = record_size
        self.data = bytearray(PAGE_SIZE)

    def __str__(self):
        s = ''
        for i in range(self.num_records):
            s += str(self.__getitem__(i))
            s += ' '
        return s

    def __getitem__(self, index: int) -> int:
        if index < 0 or index >= PAGE_SIZE / self.record_size:
            raise IndexError("index out of range")
        index = index * self.record_size
        byte_value = self.data[index: index + self.record_size]
        value = int.from_bytes(byte_value, byteorder='big')  # Added byteorder here
        return value

    def has_capacity(self) -> bool:
        return self.num_records * self.record_size < PAGE_SIZE

    def write(self, value) -> int:
        if not self.has_capacity():
            raise IndexError('Page is full')
        
        # Handle different types of values
        if type(value) != bytes:
            try:
                # If it's a list, take the first item
                if isinstance(value, list):
                    if value:  # If the list is not empty
                        value = int(value[0])
                    else:
                        value = 0  # Default value for empty list
                # Now convert to bytes
                value = int(value).to_bytes(self.record_size, byteorder='big')
            except (TypeError, ValueError, AttributeError):
                # If conversion fails, use a default value
                value = (0).to_bytes(self.record_size, byteorder='big')
                
        index = self.num_records * self.record_size
        self.data[index: index + self.record_size] = value
        self.num_records += 1
        return (self.num_records - 1)
    def update(self, index, value):
        if type(value) != bytes:
            try:
                # If it's a list, take the first item
                if isinstance(value, list):
                    if value:  # If the list is not empty
                        value = int(value[0])
                    else:
                        value = 0  # Default value for empty list
                # Now convert to bytes
                value = int(value).to_bytes(self.record_size, byteorder='big')
            except (TypeError, ValueError, AttributeError):
                # If conversion fails, use a default value
                value = (0).to_bytes(self.record_size, byteorder='big')
                
        index = index * self.record_size
        self.data[index: index + self.record_size] = value
        return True